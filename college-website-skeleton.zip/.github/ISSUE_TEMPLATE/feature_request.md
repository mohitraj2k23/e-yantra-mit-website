---
name: Feature / Task
about: A new page, section, or feature to build
title: "feat: "
labels: enhancement
assignees: ''
---

## Task
What needs to be built (e.g. "Build homepage hero section").

## Details
Describe layout, content, or functionality expected. Link Figma mockup if available.

## Acceptance Criteria
- [ ] Matches design/mockup
- [ ] Responsive on mobile
- [ ] No console errors
- [ ] Reviewed and merged into `develop`

## Deadline
YYYY-MM-DD
