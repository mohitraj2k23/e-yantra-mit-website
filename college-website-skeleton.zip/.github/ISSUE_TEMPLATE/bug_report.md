---
name: Bug Report
about: Report a bug or unexpected behavior
title: "fix: "
labels: bug
assignees: ''
---

## Description
A clear description of the bug.

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. See error

## Expected Behavior
What should happen instead.

## Screenshots
If applicable, add screenshots.

## Environment
- Browser/OS:
- Page/URL:

## Priority
- [ ] Low
- [ ] Medium
- [ ] High
